const user_role = Object.freeze({
	Patient: 'patient',
	Doctor: 'doctor',
});

module.exports = { user_role };
