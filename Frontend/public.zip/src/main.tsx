import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import GlobalStateProvider from "./context/GlobalStateProvider.tsx";
import { AuthContextProvider } from "./context/AuthContext.tsx";
import { SocketContextProvider } from "./context/SocketContext.js";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <GlobalStateProvider>
    <AuthContextProvider>
				<SocketContextProvider>
      <App />
      </SocketContextProvider>
      </AuthContextProvider>
    </GlobalStateProvider>
  </React.StrictMode>
);
