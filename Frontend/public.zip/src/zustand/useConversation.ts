import { create } from "zustand";

interface IUserConvo {
	selectedConversation: any;
	setSelectedConversation:any;
	messages: [];
	setMessages: any
}

const useConversation = create<IUserConvo>((set) => ({
	selectedConversation: null,
	setSelectedConversation: (selectedConversation : any) => set({ selectedConversation }),
	messages: [],
	setMessages: (messages : any) => set({ messages }),
}));

export default useConversation;
