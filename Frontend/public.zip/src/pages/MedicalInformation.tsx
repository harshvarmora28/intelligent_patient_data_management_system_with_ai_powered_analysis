import PatientMedicalAndLifeStyleForm from '../components/PatientMedicalAndLIfeStyle';

const MedicalInformation = () => {
	return (
		<div className='h-full flex flex-col justify-center'>
			<PatientMedicalAndLifeStyleForm />
		</div>
	);
};

export default MedicalInformation;
