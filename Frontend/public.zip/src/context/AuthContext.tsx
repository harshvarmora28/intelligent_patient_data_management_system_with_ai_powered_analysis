import { createContext, SetStateAction, useState, Dispatch, useContext } from 'react';

interface authContextI {
	authUser?: any,
	setAuthUser? : Dispatch<SetStateAction<any>>
}

export const AuthContext = createContext<authContextI>({
});

// eslint-disable-next-line react-refresh/only-export-components
export const useAuthContext = () => {
	return useContext(AuthContext);
};

export const AuthContextProvider = ({ children } : any) => {
	console.log(localStorage.getItem("chat-user"))
	const chat_user = localStorage.getItem("chat-user") ? JSON.parse(localStorage.getItem("chat-user") || "") : null
	const [authUser, setAuthUser] = useState(chat_user || null);

	return <AuthContext.Provider value={{ authUser, setAuthUser }}>{children}</AuthContext.Provider>;
};
