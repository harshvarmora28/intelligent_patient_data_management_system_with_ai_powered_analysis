import { createContext, useState, useEffect, useContext } from "react";
import io from "socket.io-client";
import { useGlobalState } from "./useGlobalState";

interface INTER {
	socket?: any;
	onlineUsers? : []
}

const SocketContext = createContext<INTER>({});

export const useSocketContext = () => {
	return useContext(SocketContext);
};

export const SocketContextProvider = ({ children } : any) => {
	const [socket, setSocket] = useState<any>(null);
	const [onlineUsers, setOnlineUsers] = useState<any>([]);
	const { state } = useGlobalState();


	useEffect(() => {
		if (state.patientProfile) {
			const socket = io("http://localhost:8080/", {
				query: {
					userId: state.patientProfile._id,
				},
			});

			setSocket(socket);

			socket.on("getOnlineUsers", (users : any) => {
				setOnlineUsers(users);
			});

			socket.close();
		} else {
			if (socket) {
				socket.close();
				setSocket(null);
			}
		}
	}, [state.patientProfile]);

	return <SocketContext.Provider value={{ socket, onlineUsers }}>{children}</SocketContext.Provider>;
};
